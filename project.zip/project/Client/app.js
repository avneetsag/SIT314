
const http = require('http');
var express = require('express');
var swig = require('swig');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var Cookies = require('cookies');
var User = require('../Client/models/User');
var app = express();
const request = require('request');
var ejs = require('ejs')
var flash = require('connect-flash');

app.use('/public',express.static(__dirname+'/public'));




const session = require('express-session')
const passport = require('passport')
const passportLocalMongoose = require('passport-local-mongoose');
const { userInfo } = require('os');

app.use(session({
    secret : '$$$ChaseTest',
    resave: false,
    saveUninitialized: false,
    cookies: {maxAge:60*1000 }

}))

    

app.use(passport.initialize());
app.use(passport.session());

app.engine('html',swig.renderFile);
app.set('views','./views');
app.set('view engine','html');
 swig.setDefaults({cache:false});

app.use(bodyParser.urlencoded({extended:true}))
app.use(function(req,res,next){
    req.cookies = new Cookies(req,res);

    req.userInfo = {};
    if(req.cookies.get('userInfo')){
        try{
            req.userInfo = JSON.parse(req.cookies.get('userInfo'));
           
            User.findById(req.userInfo._id).then((userInfo)=>{
                req.userInfo.isAdmin = Boolean(userInfo.isAdmin);
                next();
            })
        }catch(e){
            next();
        }
    }else{
        next();
    }
})
app.use('/workers',require('../Client/routers/worker'));
app.use('/admin',require('../Client/routers/passport-setup'));
app.use('/api',require('../Client/routers/api'));
app.use('/',require('../Client/routers/main'));

mongoose.connect('mongodb+srv://avneetsagg:saggu1234@cluster0.nxvee.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',function(err){
   if(err){
       console.log('Connet to MongoDB failed!');
   }else{
       console.log('Connect to MongoDB successfully!');
       app.listen(process.env.PORT || 3000);
   }
});
