var express = require('express');
var router = express.Router();
const request = require('request')
var Category = require('../models/Category');
var User = require("../models/User");
var Lighter = require("../models/bulb");
var async = require("async");
var nodemailer = require("nodemailer");
var crypto = require("crypto");
var ejs = require('ejs')
var token = '';
var googleName = '';
var display = {
  dengpao: 'Light Bulb 1',
  dengpao2:'Light Bulb 2'
}
var turnOnTime = 0
var turnOffTime = 0

var xiaofengName = 'XIAODFENGYIN 哈哈哈哈'

var session = require("express-session");

router.use(session({
  secret : '$$$ChaseTest',
  resave: false,
  saveUninitialized: false,
  cookie: {maxAge:60*1000}

}))


var responseData;
router.use(function(req,res,next){
    responseData = {
        code:0,
        message:''
    }
    next();
})
var resData;
router.use(function(req,res,next){
  resData = {
      code:0,
      message:''
  }
  next();
})


const passport = require('passport');
const cors = require('cors')
const bodyParser = require('body-parser');
const { userInfo } = require('os');
require('./passport-setup')

router.use(cors())
router.use(bodyParser.urlencoded({extended: false}))
router.use(bodyParser.json())

router.get('/',function(req,res,next){
        res.render('main/index',{
            userInfo:req.userInfo  
        })
})

router.get('/changePassword',function(req,res,next){
    res.render('main/changePassword',{});
});

  router.get('/sentEmail',function(req,res,next){
    res.render('main/sentEmail',{});
});


router.get('/about',function(req,res,next){
    res.render('main/about',{});
});

router.get('/floor1',function(req,res,next){
  res.render('main/floor1',{});
});


router.get('/bulbCheck', function(req, res) {

  Lighter.find({
    'id': { $in: [
        1,2,3,4,5,6,7,8,9,10
    ]}
}, function(err, docs){
     console.log(docs);
     var jsonDoc = JSON.stringify(docs)
     console.log('The json obtained is :'+jsonDoc.switch)
     res.json(docs)
    
});

});


router.get('/bulbAjax', function(req, res) {
  Lighter.find({
    'id': { $in: [
        1,2,3,4,5,6,7,8,9,10
    ]}
}, function(err, docs){
     res.json(docs)
});

});


router.get('/turnOnFloor1', function(req, res) {
  turnOnTime = turnOnTime + 1
  Lighter.updateMany({
    'id': { $in: [
        1,2,3,4,5,6,7,8,9,10
    ]}
}, {$set:{userClick:true, switch: 'on', clickTime: turnOnTime, brightness:50, color:'Yellow'}},function(err, res){
  if(err){
    console.log('Update Failed: '+err)
  }
  else
  {
    console.log('Bulb Turned on Successfully! '+res)
  }
});

});
router.get('/turnOffFloor1', function(req, res) {
  turnOffTime = turnOffTime + 1
   Lighter.updateMany({
    'id': { $in: [
        1,2,3,4,5,6,7,8,9,10
    ]}
}, {$set:{userClick:true, switch: 'off', clickTime: turnOffTime, brightness:0, color:'0'}},function(err, res){
  if(err){
    console.log('Update Failed: '+err)
  }
  else
  {
    console.log('Bulb Turned off Successfully! '+res)
  }
});

});

router.get('/bulb', (req, res)=> {
  res.render('main/bulb',{});
})

router.get('/changebulb/:id', (req, res)=> {
  var id = req.params.id;
  Lighter.findOne({
    id:id
  }).then(bulbInfo => {
    if(bulbInfo.switch=='off')
    {
      bulbInfo.switch = 'on'
      bulbInfo.userClick = true
      bulbInfo.clickTime = bulbInfo.clickTime + 1
      bulbInfo.brightness = 50
      bulbInfo.color = 'Yellow'
      bulbInfo.save()
      res.render('main/floor1')
    }
    else
    {
      bulbInfo.switch = 'off'
      bulbInfo.userClick = true
      bulbInfo.clickTime = bulbInfo.clickTime + 1
      bulbInfo.brightness = 0
      bulbInfo.color = '0'
      bulbInfo.save()
      res.render('main/floor1')
    }
    
  })

})
router.get('/turnOnbulb/:id', function(req, res) {
  
  var id = req.params.id;

  console.log('Turned on Bulb ID:'+id);

  Lighter.findOne({
    id:id
  }).then(bulbInfo => {
    if(bulbInfo)
    {
      bulbInfo.switch = 'on'
      bulbInfo.userClick = true
      bulbInfo.clickTime = bulbInfo.clickTime + 1
      bulbInfo.brightness = 50
      bulbInfo.color = 'Yellow'
      bulbInfo.save()
      console.log('Bulb No. Turned On：'+id)
    }
    else
    {
      console.log('Bulb Not Found!')
    }
    
  })

});

router.get('/turnOffbulb/:id', function(req, res) {
  var id = req.params.id;

  console.log('ID of Bulb is:'+id);

  Lighter.findOne({
    id:id
  }).then(bulbInfo => {
    if(bulbInfo)
    {
      bulbInfo.switch = 'off'
      bulbInfo.userClick = true
      bulbInfo.clickTime = bulbInfo.clickTime + 1
      bulbInfo.brightness = 0
      bulbInfo.color = '0'
      bulbInfo.save()
      console.log('Bulb Turned off：'+id)
    }
    else
    {
      console.log('Bulb Not Found!')
    }
    
  })

});

router.get('/bulbMore/:id', function(req, res) {
  
  var id = req.params.id;
  var brightness
  var type
  console.log('ID of Bulb is:'+id);

  Lighter.findOne({
    id:id
  }).then(bulbInfo => {
    if(!bulbInfo)
    {
      console.log('Bulb Not Found!')
    }
    else{
      brightness = bulbInfo.brightness
      type = bulbInfo.type
    }
    console.log('Updated Brightness: '+brightness)
    res.render('main/morebulb',{
      id:id,
      brightness:brightness,
      type:type
    });
  })
  

});

router.post('/bulbUpdate', function(req, res) {
  var doc = JSON.stringify(req.body)
  console.log('Request 1 received: '+doc)  
  console.log('Received request: '+req.body.type)  
  console.log('Received request: '+req.body.color)  

  Lighter.findOne({
    id:req.body.id
  }).then(bulbInfo => {
    if(!bulbInfo)
    {
      console.log('Bulb Not Found! ')
    }
    else{
      bulbInfo.switch = 'on'
      bulbInfo.brightness = req.body.brightness
      bulbInfo.type = req.body.type
      bulbInfo.color = req.body.color
      bulbInfo.colorTemperature = req.body.colorTemperature
      bulbInfo.save()
    }
    
  })
});
module.exports = router;