const validator = require('validator')
const request = require('request')
var express = require('express');
var router = express.Router();
var User = require("../models/User");
var async = require("async");
var nodemailer = require("nodemailer");
var crypto = require("crypto");

const session = require('express-session')

var crypto = require('crypto');
const { response } = require('express');
const { userInfo } = require('os');
const { SSL_OP_NETSCAPE_REUSE_CIPHER_CHANGE_BUG } = require('constants');
const { error } = require('console');

module.exports = router;