var mongoose = require('mongoose');
var bulbSchema = require('../schemas/bulb');
var passportLocalMongoose = require("passport-local-mongoose");

module.exports = mongoose.model('bulb',bulbSchema);