const mongoose = require("mongoose")
mongoose.connect("mongodb+srv://avneetsagg:saggu1234@cluster0.nxvee.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",{useNewUrlParser: true})

var i = 1;
var increase;
var decrease;
var decreaseTime = 1
var improveTime = 1;
const bulbSchema = new mongoose.Schema(
	{
		id:Number,
		switch:String,
		userClick:false,
		nearLight:Number,
		time: Date,
		brightness:Number,
		clickTime:Number,
		type:String,
		colorTemperature:Number,
		color:String
	}
)

const bulb = new mongoose.model("bulb",bulbSchema)
const Bulb = new mongoose.model("bulb",bulbSchema)

var interval = setInterval(insertbulb,2000);

function insertbulb()
{
	const bulb1 = new bulb(
	{
		id:i,
		switch:'off',
		userClick:false,
		nearLight:0,
		time: Date.now(),
		brightness:0,
		clickTime:0,
		type:'Room',
		colorTemperature:1300,
		color:'0'
	});
	bulb1.save().then(doc => {
        console.log(doc);
		console.log("set up successfully");
		i = i+1
	})
	if(i==10)
	{
		console.log('灯泡初始化完毕')
		clearInterval(interval);
		setTimeout(function(){ improveLight() }, 20000);
	}
	
}

function improveLight(){
	bulb.updateMany({
		'id': { $in: [
			8,9,10
		]}
	}, {$set:{type:'Corridor'}},function(err, res){
	  if(err){
		console.log('Update failed'+err)
	  }
	  else
	  {
		console.log('Successfully update'+res)
	  }
	}).then(function(){
		increase = setInterval(increaseLight, 40000)
	});

	
}
function increaseLight()
{
	if(improveTime!=11){
	console.log('Start improving environmental brightness')
	console.log('The improve time is :'+improveTime)
	var i = 1;
	var interval = setInterval(autoLight,2000);
	function autoLight()
	{
		bulb.findOne({
		id:i
	}).then(bulbInfo => {
		if(bulbInfo)
		{
			bulbInfo.nearLight = improveTime * 10	
			console.log('Find bulb:'+bulbInfo)
			i = i+1
			bulbInfo.save()
		}
		else{
			console.log('All bulbs have been updated!')
			improveTime = improveTime + 1
			i = 1;
			clearInterval(interval);
			}
		})
	}
	}
	else{
	console.log('Start decreasing brightness...')
	clearInterval(increase);
	improveTime = 1;
	decrease = setInterval(decreaseLight, 40000)
	}
}

function decreaseLight(){
	var num = 1;
	if(decreaseTime!=11)
	{
		var decreaseInterval = setInterval(autoDecrease,2000);
		function autoDecrease(){
			bulb.findOne({
				id:num
			}).then(bulbInfo => {
				if(bulbInfo)
				{
					bulbInfo.nearLight = 100 - decreaseTime * 10	
					console.log('Find bulbs：'+bulbInfo)
					num = num+1
					bulbInfo.save()
				}
				else{
					console.log('All bulbs have been updated!')
					decreaseTime = decreaseTime + 1
					num = 1;
					clearInterval(decreaseInterval);
				}
				
			})
		}
	}
	else
	{
		console.log('Strat increasing brightness')
		clearInterval(decrease);
		decreaseTime = 1;
		increase = setInterval(increaseLight, 40000)
	}
}


setInterval(autoSwitchLighter, 15000)
function autoSwitchLighter(){
	var num = 8;
	var switchLighter = setInterval(autoSwitch, 2000)
	function autoSwitch(){
		bulb.findOne({
			id:num,
			type:'Corridor'
		}).then(bulbInfo => {
			if(bulbInfo)
			{
				if(bulbInfo.clickTime%2==1)
				{
					console.log('Bulb：'+num+'is not in auto controling')
					num = num + 1
				}
				else
				{
					if(bulbInfo.nearLight>50)
					{
						bulbInfo.switch = 'off'
						bulbInfo.brightness = 0
						bulbInfo.color = '0'
						console.log('==========Auto================Turn off corridor bulb：'+bulbInfo.id+'===================')
						num = num+1
						bulbInfo.save()
					}
					else
					{
						if(bulbInfo.voice>50)
						{
							bulbInfo.switch = 'on'
							bulbInfo.brightness = 75
							bulbInfo.color = 'Yellow'
							bulbInfo.save()
							num = num + 1
						}
						else
						{
							bulbInfo.switch = 'on'
							bulbInfo.brightness = 50
							bulbInfo.color = 'Yellow'
							bulbInfo.save()
							num = num + 1
						}
						
						
					}
				}
				
			}
			else{
				console.log('Auto control finished!')
				num = 1;
				clearInterval(switchLighter);
			}
			
		})
	}
}