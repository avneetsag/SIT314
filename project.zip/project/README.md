# smartLightingControl
This repository is used to store relevant codes of final project.

It is a spell mistake that I use 'bulb' to represent 'bulb'. Sorry to make you confused.
